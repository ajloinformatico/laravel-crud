Cookbook
========

.. toctree::
    :hidden:

    default_expectations
    detecting_mock_objects
    not_calling_the_constructor
    mocking_hard_dependencies
    class_constants
    big_parent_class
    mockery_on
    mocking_class_within_class

.. include:: map.rst.inc
